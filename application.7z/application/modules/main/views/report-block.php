<a href="http://hb.dev/main/report/?r=<?=$iPrevMonth.'-'.$iPrevYear;?>
">Предыдущий</a>
<a href="http://hb.dev/main/report/?r=<?=$iNextMonth.'-'.$iNextYear;?>
">Следующий</a>
